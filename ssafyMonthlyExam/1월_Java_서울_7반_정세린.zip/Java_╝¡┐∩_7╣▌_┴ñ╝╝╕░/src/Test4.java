import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Test4 {
	static int N, Si, Sj, P, D, itmp, jtmp;
	static int Answer, dir, len;
	static boolean[][] map;
	static int[][] dh = { { 0, 0 }, { 0, -1 }, { 1, -1 }, { 1, 0 }, { 1, 1 }, { 0, 1 }, { -1, 1 }, { -1, 0 },
			{ -1, -1 } };
	static boolean flag;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("Test4.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = null;

		int T = Integer.parseInt(br.readLine());
		for (int test_case = 1; test_case <= T; test_case++) {

			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			Si = Integer.parseInt(st.nextToken()); // 출발점의 i좌표
			Sj = Integer.parseInt(st.nextToken()); // 출발점의 j좌표
			P = Integer.parseInt(st.nextToken());
			map = new boolean[N + 1][N + 1];
			Answer = 0;

			st = new StringTokenizer(br.readLine());
			for (int k = 0; k < P; k++) { // 함정 좌표 읽어서 저장
				int i = Integer.parseInt(st.nextToken());
				int j = Integer.parseInt(st.nextToken());
				map[i][j] = true; // 함정
			}

			D = Integer.parseInt(br.readLine()); // 이동 지시 개수

			st = new StringTokenizer(br.readLine());
			L: for (int k = 0; k < D; k++) { // 방향, 이동칸수 읽어서 저장
				flag = false;
				dir = Integer.parseInt(st.nextToken());
				len = Integer.parseInt(st.nextToken());

				for (int l = 0; l < len; l++) {
					itmp = Si + dh[dir][1];
					jtmp = Sj + dh[dir][0];
					if (itmp > 0 && itmp < N + 1 && jtmp > 0 && jtmp < N + 1) {
						if (map[itmp][jtmp]) {
							break L;
						} else {
							Answer++;
							Si = itmp;
							Sj = jtmp;
						}

					} else
						break L;
				}

			}

			System.out.println("#" + test_case + " " + Answer);
		}
	}

}