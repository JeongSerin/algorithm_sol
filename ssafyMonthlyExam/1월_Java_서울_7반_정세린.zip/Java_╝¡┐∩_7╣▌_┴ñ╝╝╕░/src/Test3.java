
public class Test3 {

	public static void main(String[] args) {
		Test3 c = new Test3();
		c.execute("5329053995535987827332679340558347453272569584");
		c.execute("122333444455555666666");
	}

	public void execute(String msg) {
		int[] cnt = new int[10];
		for (int i = 0; i < msg.length(); i++) {
			int a = msg.charAt(i) - 48;
			cnt[a]++;
		}
		for (int i = 0; i < 10; i++) {
			if (cnt[i] == 0)
				continue;
			System.out.printf("%d : %d\n", i, cnt[i]);
		}

	}
}
