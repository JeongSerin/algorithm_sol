import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String ch = s.next();
		char c = ch.charAt(0);
		int num = 1;
		switch (c) {
		case '1':
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j <= i; j++) {
					System.out.print(num++ + " ");
				}
				System.out.println();
			}
			break;

		case 'A':
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j <= 4 + i; j++) {
					if (j < 4 - i)
						System.out.print(" ");
					else
						System.out.print(c++ + "");
				}
				System.out.println();
			}
			break;

		default:
			break;
		}
	}

}
