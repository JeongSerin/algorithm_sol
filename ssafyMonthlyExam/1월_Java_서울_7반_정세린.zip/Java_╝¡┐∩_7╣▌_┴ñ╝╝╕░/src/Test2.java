
public class Test2 {

	public static void main(String[] args) {

		int[] su = { 34, 55, 27, 67, 45, 82, 68, 99, 77, 18 };
		int sum = 0;
		int min = abs(su[0] - su[1]);
		int sutmp = 0;
		for (int s : su) {
			sum += s;
		}

		int avg = sum / su.length;

		for (int s : su) {
			int tmp = abs(s - avg);
			if (tmp < min) {
				min = tmp;
				sutmp = s;
			}
		}

		System.out.println(avg + " " + sutmp);

	}

	private static int abs(int num) {
		if (num < 0)
			return num * (-1);
		else
			return num;
	}
}
