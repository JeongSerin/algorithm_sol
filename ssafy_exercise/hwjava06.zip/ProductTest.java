package com.ssafy;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ProductTest {
	public static final int searchProductAll=1;
	public static final int searchByProductNum=2;
	public static final int searchByProductName=3;
	public static final int searchKindTV=4;
	public static final int searchKindRefrigerator=5;
	public static final int removeByProductNo=6;
	public static final int inventoryAmount=7;
	
	public static void printProductInfo() {
		
	}
	
    public static void main(String[] args) throws Exception{
//    	상품정보 전체를 검색하는 기능
//    	상품번호로 상품을 검색하는 기능
//    	상품명으로 상품을 검색하는 기능(상품명 부분 검색 가능)
//    	TV정보만 검색
//    	Refrigerator만 검색
//    	상품번호로 상품을 삭제하는 기능
//    	전체 재고 상품 금액을 구하는 기능
       ProductMgr mgr = new ProductMgr();
       
       BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
       int no;
       do {
    	 System.out.println("\t\t\t<<상품메뉴>>");
    	 System.out.println("===========================================================");
    	 System.out.println("\t1.전체검색   2.상품검색(상품번호)  3.상품검색(상품명)");
    	 System.out.println("\t4.TV검색     5.Refrigerator검색");
    	 System.out.println("\t6.상품삭제   7.재고상품 금액            8.종료");
    	 System.out.println("===========================================================");
    	
    	 System.out.print("\n\t번호입력>>> ");
    	 no=Integer.parseInt(in.readLine());
    	 System.out.println();
 	 
    	 switch(no) {
    	    case searchProductAll: 
    	    	 Product [] products=mgr.searchProductAll();
    	    	 for(Product p : products) {
    	    		 System.out.println(p);
    	    	 }
    	    	 break;
    	    case searchByProductNum: 
    	    	 System.out.print("검색할 상품번호: ");
    	    	 String productNum=in.readLine();
    	    	 Product p= mgr.searchByProductNum(productNum);
    	    	 if(p!=null)System.out.println(p);
    	    	 break;
    	    case searchByProductName: 
    	    	 System.out.print("검색할 상품명: ");
   	    	     String productName=in.readLine();
   	    	     System.out.println(mgr.searchByProductName(productName));
    	    	 break;
    	    case searchKindTV: 
    	    	 System.out.println(mgr.searchKindTV());
    	    	 break;
    	    case searchKindRefrigerator: 
    	    	 System.out.println(mgr.searchKindRefrigerator());
    	    	 break;
    	    case removeByProductNo: 
    	    	 System.out.print("삭제할 상품번호: ");
    	    	 String delProductNum=in.readLine();
    	    	 mgr.removeByProductNo(delProductNum);
    	    	 break;
    	    case inventoryAmount: 
    	    	 System.out.println("재고 총 금액은 " +mgr.inventoryAmount()+"원 입니다");
    	    	 System.out.println(String.format("재고 총 금액은 %,d원 입니다.", mgr.inventoryAmount()));
    	    	 break;
    	 }
    	 System.out.println();
       }while(no!= 8);
       System.out.println("\t-- END --");
    }
}



