package com.ssafy;

public class Product {
    //상품(TV와 Refrigerator)들의 공통 정보
	//제품 번호, 제품 이름, 가격, 수량
    //==> Encapsulation적용
	private String productNum;
    private String productName;
    private int price;
    private int amount;
    
    //Default Constructor
    public Product() {}

    //Overloading Constructor
	public Product(String productNum, String productName, int price, int amount) {
		this.productNum = productNum;
		this.productName = productName;
		this.price = price;
		this.amount = amount;
	}

	//Getters & Setters
	public String getProductNum() {
		return productNum;
	}

	public void setProductNum(String productNum) {
		this.productNum = productNum;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	//toString()적용
	public String toString() {
		StringBuilder builder = new StringBuilder();
			builder.append("productNum=");
			builder.append(productNum);
			builder.append(", productName=");
			builder.append(productName);
			builder.append(", price=");
			builder.append(price);
			builder.append(", amount=");
			builder.append(amount);
		return builder.toString();
	}
}
