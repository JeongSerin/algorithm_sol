package com.ssafy;

public class TV extends Product{
	//제품 번호, 제품 이름, 가격, 수량 (Product부모클래스에서 정의)
	//인치, 디스플레이 타입 - TV속성 추가
    //==> Encapsulation적용

    private int inch;	
    private String displayType;

    //Default Constructor
    public TV() {}

    //Overloading Constructor
    public TV(String productNum, String productName, int price,
    		int amount, int inch, String displayType) {
        super(productNum, productName, price, amount);
        this.inch=inch;
        this.displayType=displayType;
    }

	//Getters & Setters
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}

	public String getDisplayType() {
		return displayType;
	}
	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}


	//toString()적용
	public String toString() {
		StringBuilder builder = new StringBuilder();
			builder.append("▷ TV [");
			builder.append(super.toString());
			builder.append(", inch=");
			builder.append(inch);
			builder.append(", displayType=");
			builder.append(displayType);
			builder.append("]");
		return builder.toString();
	}
}