package com.ssafy;

public class Refrigerator extends Product{
	//제품 번호, 제품 이름, 가격, 수량 (Product부모클래스에서 정의)
	//용량(L) - Refrigerator속성 추가
	//==> Encapsulation적용
	private int liter;

	//Default Constructor
    public Refrigerator() {}

    //Overloading Constructor
    public Refrigerator(String productNum, String productName,
    		int price, int amount, int liter) {
        super(productNum, productName, price, amount);
        this.liter = liter;
    }

	//Getters & Setters
	public int getLiter() {
		return liter;
	}
	public void setLiter(int liter) {
		this.liter = liter;
	}

	//toString()적용
	public String toString() {
		StringBuilder builder = new StringBuilder();
			builder.append("▷ Refrigerator [");
			builder.append(super.toString());
			builder.append(", liter=");
			builder.append(liter);
			builder.append("]");
		return builder.toString();
	}
}