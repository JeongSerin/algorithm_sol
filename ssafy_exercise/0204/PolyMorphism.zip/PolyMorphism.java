package chap5.base;

public class PolyMorphism {

	public String name;
	
	public PolyMorphism() {}
	public PolyMorphism(String name) {
		this.name = name;
	}

	public void m1() {
		System.out.println("Parent - m1() is called");
	}
}
