package chap5.base;

public class PolyMorphismSubASubC extends PolyMorphismSubA{

	public String name;
	
	public PolyMorphismSubASubC() {}
	public PolyMorphismSubASubC(String name) {
		this.name = name;
	}

	public void m1() {
		System.out.println("Child A - Child C - m1() is called");
	}
}
