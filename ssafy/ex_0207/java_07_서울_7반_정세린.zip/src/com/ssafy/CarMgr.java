package com.ssafy;

public class CarMgr {

	private Car[] cars = new Car[100];
	private int index;

	public void add(Car c) {
		cars[index++] = c;
	}

	public Car[] search() {
		Car[] searchCar = new Car[index];
		for (int i = 0; i < index; i++) {
			searchCar[i] = cars[i];
		}
		return searchCar;
	}

	public Car search(String num) {
		int i;
		boolean founded = false;
		for (i = 0; i < index; i++) {
			if (cars[i].getNum().equals(num)) {
				founded = true;
				break;
			}
		}
		if (founded) return cars[i];
		else {
			System.out.printf("%s can not found.", num);
			return null;
		}
	}

	public Car[] search(int price) {
		int[] cararrIndex = new int[100];
		int j = 0;

		for (int i = 0; i < index; i++) {
			if (cars[i].getPrice() < price)
				cararrIndex[j++] = i;
		}

		Car[] priceUnderCar = new Car[j];
		for (int i = 0; i < j; i++) {
			priceUnderCar[i] = cars[cararrIndex[i]];
		}
		return priceUnderCar;
	}

	public void update(String num, int price) {
		boolean founded = false;
		for (int i = 0; i < index; i++) {
			if (cars[i].getNum().equals(num)) {
				founded = true;
				cars[i].setPrice(price);
				System.out.println(cars[i]);
				return;
			}
		}
		if (!founded){
			System.out.printf("%s can not found.", num);
		}
		
	}

	public void delete(String num) {
		boolean founded = false;
		for (int i = 0; i < index; i++) {
			if (cars[i].getNum().equals(num))
				for (; i < index; i++) {
					founded = true;
					cars[i] = cars[i + 1];
				}
		}
		if (!founded){
			System.out.printf("%s can not found.", num);
			return;
		}
		index = index - 1;
	}

	public int size() {
		return index;
	}

	public int totalPrice() {
		int sumPrice = 0;
		for (int i = 0; i < index; i++) {
			sumPrice += cars[i].getPrice();
		}
		return sumPrice;
	}

}
