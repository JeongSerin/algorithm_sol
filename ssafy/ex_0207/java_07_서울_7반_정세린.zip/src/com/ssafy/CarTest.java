package com.ssafy;

public class CarTest {

	public static void main(String[] args) {
		CarMgr cm = new CarMgr();
		cm.add(new Car("서울가1234", "부루루룽", 80000000));
		cm.add(new Car("경기가7890", "자동차불응", 90000000));
		cm.add(new Car("울산라5555", "불응자동차", 15000));
		cm.add(new Car("강릉라7777", "짱좋은차", 1500000000));

		// 전체 정보
		System.out.println("======== search all ========");
		Car[] cars = cm.search();
		for (int i = 0; i < cars.length; i++) {
			System.out.println(cars[i]);
		}

		// 같은 번호의 차량
		System.out.println("======== search sameNum ========");
		Car sameNum = cm.search("서울가1234");
		System.out.println(sameNum);

		// 더 낮은 가격의 차량들
		System.out.println("======== search lowerPeiceCars ========");
		Car[] lowerPeiceCars = cm.search(90000000);
		for (int i = 0; i < lowerPeiceCars.length; i++) {
			System.out.println(lowerPeiceCars[i]);
		}

		// 차량 가격 수정
		System.out.println("======== update carPrice ========");
		cm.update("울산라5555", 55555555);

		// 차량 삭제
		System.out.println("======== delete Car ========");
		cm.delete("강릉라7777");
		// 전체 정보
		Car[] cars2 = cm.search();
		for (int i = 0; i < cars2.length; i++) {
			System.out.println(cars2[i]);
		}

		// 차량 대수
		System.out.println("======== Counting Car ========");
		int cnt = cm.size();
		System.out.println(cnt);

		// 차량의 금액 합계
		System.out.println("======== Total Price ========");
		int totalPrice = cm.totalPrice();
		System.out.println(totalPrice);

		cm.search("14554");

	}
}
