package hwjava05_서울_7반_정세린;

public class TV {
	private int number;
	private String name;
	private int price;
	private int stock;
	private int inch;
	private String displayType;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	public String getDisplayType() {
		return displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}

	public void tvInfo() {
		System.out.printf("제품 번호: %s\n" + "제품이름: %s\n" + "가격: %s\n" + "수량: %s\n" + "인치: %s\n" + "디스플레이 타입: %s\n",
				number, name, price, stock, inch, displayType);

	}
}
