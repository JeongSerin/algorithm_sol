package hwjava05_서울_7반_정세린;

public class ProductTest {
	
	public static void main(String[] args) {
		TV tv1 = new TV();
		Refirigerator refirigerator1 = new Refirigerator();
		
		tv1.setNumber(11120);
		tv1.setName("samsung");
		tv1.setPrice(1000000);
		tv1.setStock(150);
		tv1.setInch(25);
		tv1.setDisplayType("LED");
		
		refirigerator1.setNumber(11120);
		refirigerator1.setName("samsung");
		refirigerator1.setPrice(1000000);
		refirigerator1.setStock(150);
		refirigerator1.setL(100);
		
	
		tv1.tvInfo();
		System.out.println();
		refirigerator1.refirigeratorInfo();

	}

}
