package chap5.base;

public class PolyMorphismSubA extends PolyMorphism{

	public String name;
	public int number;
	
	public PolyMorphismSubA() {}
	public PolyMorphismSubA(String name) {
		this.name = name;
	}

	public void m1() {
		System.out.println("Child A - m1() is called");
	}
}
