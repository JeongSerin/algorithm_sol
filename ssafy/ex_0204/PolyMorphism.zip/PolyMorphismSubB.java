package chap5.base;

public class PolyMorphismSubB extends PolyMorphism{

	public PolyMorphismSubB() {}
	public PolyMorphismSubB(String name) {
		//super(name);
	}
	
//	public void m1() {
//		System.out.println("Child B - m1() is called");
//	}
}
