package com.ssafy;

public class BookTest {

	public static void main(String[] args) {
		Book[] books = new Book[5];
		
		System.out.println("=====입력===========");
		books[0] = new Book("1111", "java start", "JMK", "SSAFY1", 10000, "SW ALGO");
		books[1] = new Book("7777", "Web", "JMK", "SSAFY1", 10000, "SW ALGO");
		books[2] = new Magazine("2222", "IT Tech", "KMJ", "SSAFY2", 20000, "ALGO SW", 2019, 01);
		books[3] = new Magazine("2222", "IT java", "KKK", "SSAFY3", 30000, "ALGO SW", 2019, 05);
		books[4] = new Book("5555", "Web world", "kim", "SSAFY3", 25000, "AD ALGO");
				
		System.out.println("=====모두검색===========");
		for (Book b : books) {
			System.out.println(b);
		}
		System.out.println("=====isbn 검색===========");
		for (Book b : books) {
			if (b.getIsbn().equals("1111")) {
				System.out.println(b);
				break;
			}
		}
		
		System.out.println("=====title 검색===========");
		for (Book b : books) {
			if (b.getTitle().contains("java")) System.out.println(b);
		}
		System.out.println("======도서 검색==============");
		for (Book b : books) {
			if (!(b instanceof Magazine)) System.out.println(b);
		}		
		
		System.out.println("======잡지검색==============");
		for (Book b :books) {
			if ((b instanceof Magazine))System.out.println(b);
		}
		
		System.out.println("======출판사 검색==============");
		for (Book b :books) {
			if (b.getPublisher().equals("SSAFY1")) System.out.println(b);
		}
		
		System.out.println("======가격 검색==============");
		for (Book b :books) {
			if (b.getPrice() <= 20000) System.out.println(b);
		}
		System.out.println("======도서 금액의 합계==============");
		int total = 0;
		for (Book b :books) {
			total += b.getPrice();
		}
		System.out.println(total);
		System.out.println("평균 :"+total/5);
		
	}

}
